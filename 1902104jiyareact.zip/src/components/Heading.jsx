import React from "react";

class Heading extends React.Component {
	render() {
		return <h1>I am a Heading Component</h1>;
	}
}

export default Heading;
