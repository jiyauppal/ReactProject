import React from "react";

function Transaction() {
	return (
		<div>
			<h2>Transactions</h2>
		</div>
	);
}

export default Transaction;
